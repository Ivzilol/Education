package magicGame.models.magics;

public interface Magic {
    String getName();

    int getBulletsCount();

    int fire();
}
