package christmasPastryShop.common.enums;

public enum CocktailType {
    MulledWine,
    Hibernation
}
