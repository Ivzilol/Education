package glacialExpedition.core;

public interface Engine extends Runnable {
}
